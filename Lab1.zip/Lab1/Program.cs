﻿
using var game = new Lab1.Game1();
game.Run();
